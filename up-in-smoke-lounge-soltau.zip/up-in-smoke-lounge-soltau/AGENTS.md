<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Render header smoke using a separate transparent image overlay and CSS transforms; this keeps the official logo and original photograph unchanged and honors reduced-motion preferences.
- Embed the location map through a lazy-loaded Google Maps iframe and keep privacy disclosures consistent with the provider, without adding client-side mapping dependencies.
- The drinks menu lives in `src/data/menu.ts` (real items/prices transcribed from the menu photos) and renders through `src/components/drinks-menu.tsx (inline on the homepage, no popup)` with framer-motion transitions; every drink has its own generated image in src/assets/drinks/<slug>.jpg (slug via drinkSlug), category image is only a fallback.
