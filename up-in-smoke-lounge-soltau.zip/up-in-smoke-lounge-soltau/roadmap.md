# Roadmap

- [x] Getränkekarte als interaktive Premium-Ansicht umbauen: 4 Kategorien mit echten Preisen aus den Kartenbildern, animierte Bild- und Textwechsel (framer-motion), 4 neue Kategorie-Bilder
- [x] Kartenwechsel, Schnellklicks, Escape-Schließen und Build im Browser geprüft

- [x] Google-Karte links unter dem Standorttext neben den Öffnungszeiten platzieren
- [x] Rauch deutlich verstärken und weiter rechts platzieren
- [x] Kartenansicht und Rauch auf Desktop und Mobilgerät prüfen

- [x] Animierten Rauch im oberen Bildbereich ergänzen, Original-Logo unverändert lassen
- [x] Fehlende Standortkarte ergänzen und Getränkekarte prüfen
- [x] Darstellung auf Desktop und Mobilgerät, Rauchbewegung und alle vier Getränkeseiten prüfen; Standortkarte sichtbar bestätigt

- [x] Lovable-Wasserzeichen auf der veröffentlichten Website ausblenden
- [x] UP-Logo als Browser- und Suchmaschinen-Symbol bereitstellen
- [x] Abgeschnittene Schrift im mobilen Header korrigieren
- [x] Änderungen prüfen
- [x] Logo/Favicon technisch abgesichert (Veröffentlichung + Google-Cache offen)
