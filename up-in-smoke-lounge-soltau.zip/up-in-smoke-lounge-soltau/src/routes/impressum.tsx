import { createFileRoute, Link } from "@tanstack/react-router";
import { BrandLogo } from "@/components/brand-logo";

export const Route = createFileRoute("/impressum")({
  staticData: { sitemap: true },
  component: Impressum,
  head: () => ({
    meta: [
      { title: "Impressum | UP IN SMOKE LOUNGE Soltau" },
      { name: "description", content: "Impressum und Anbieterkennzeichnung der UP IN SMOKE LOUNGE, Wilhelmstraße 25, 29614 Soltau." },
      { property: "og:title", content: "Impressum | UP IN SMOKE LOUNGE Soltau" },
      { property: "og:description", content: "Impressum und Anbieterkennzeichnung der UP IN SMOKE LOUNGE in Soltau." },
      { property: "og:type", content: "article" },
      { property: "og:url", content: "https://upinsmoke-soltau.de/impressum" },
      { property: "og:image", content: "https://upinsmoke-soltau.de/og-image.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: "https://upinsmoke-soltau.de/og-image.jpg" },
    ],
    links: [{ rel: "canonical", href: "https://upinsmoke-soltau.de/impressum" }],
  }),
});

function Impressum() {
  return (
    <>
      <header className="legal-header">
        <BrandLogo />
        <Link to="/" className="legal-back">← Zurück zur Startseite</Link>
      </header>
      <main className="legal-page">
        <p className="legal-kicker">Rechtliches</p>
        <h1>Impressum</h1>

      <h2>Angaben gemäß § 5 DDG</h2>
      <p>Up in Smoke<br />Inhaber: Ali Hossaini<br />Wilhelmstraße 25<br />29614 Soltau</p>

      <h2>Kontakt</h2>
      <p>Telefon: <a href="tel:+4915226392702">01522 6392702</a></p>

      <h2>Aufsichtsbehörde / Erlaubnisse</h2>
      <p>Gaststättenerlaubnis nach § 2 GastG — zuständige Behörde: Stadt Soltau.</p>


      <h2>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</h2>
      <p>Ali Hossaini<br />Wilhelmstraße 25, 29614 Soltau</p>

      <h2>EU-Streitschlichtung</h2>
      <p>
        Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:{" "}
        <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noreferrer">https://ec.europa.eu/consumers/odr/</a>. Wir sind nicht bereit oder
        verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
      </p>

        <h2>Umsatzsteuer-ID</h2>
        <p>Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz:<br />DE410743843</p>
      </main>
    </>
  );
}
