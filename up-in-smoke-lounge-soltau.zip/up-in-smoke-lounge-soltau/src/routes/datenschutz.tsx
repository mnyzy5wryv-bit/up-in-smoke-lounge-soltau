import { createFileRoute, Link } from "@tanstack/react-router";
import { BrandLogo } from "@/components/brand-logo";

export const Route = createFileRoute("/datenschutz")({
  staticData: { sitemap: true },
  component: Datenschutz,
  head: () => ({
    meta: [
      { title: "Datenschutzerklärung | UP IN SMOKE LOUNGE Soltau" },
      { name: "description", content: "Datenschutzerklärung der UP IN SMOKE LOUNGE in Soltau: welche Daten verarbeitet werden, Cookies und deine Rechte." },
      { property: "og:title", content: "Datenschutzerklärung | UP IN SMOKE LOUNGE Soltau" },
      { property: "og:description", content: "Wie wir mit deinen Daten umgehen – UP IN SMOKE LOUNGE Soltau." },
      { property: "og:type", content: "article" },
      { property: "og:url", content: "https://upinsmoke-soltau.de/datenschutz" },
      { property: "og:image", content: "https://upinsmoke-soltau.de/og-image.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: "https://upinsmoke-soltau.de/og-image.jpg" },
    ],
    links: [{ rel: "canonical", href: "https://upinsmoke-soltau.de/datenschutz" }],
  }),
});

function Datenschutz() {
  return (
    <>
      <header className="legal-header">
        <BrandLogo />
        <Link to="/" className="legal-back">← Zurück zur Startseite</Link>
      </header>
      <main className="legal-page">
        <p className="legal-kicker">Rechtliches</p>
        <h1>Datenschutzerklärung</h1>

      <h2>1. Verantwortlicher</h2>
      <p>
        Up in Smoke<br />Inhaber: Ali Hossaini<br />Wilhelmstraße 25<br />29614 Soltau<br />
        Telefon: <a href="tel:+4915226392702">01522 6392702</a><br />E-Mail: [E-Mail-Adresse]
      </p>

      <h2>2. Allgemeines zur Datenverarbeitung</h2>
      <p>
        Beim Besuch dieser Website werden durch den Hosting-Anbieter automatisch technische Zugriffsdaten (sog. Server-Logfiles)
        verarbeitet, z. B. IP-Adresse, Datum und Uhrzeit des Zugriffs, abgerufene Datei, Referrer und Browsertyp. Diese Daten sind
        technisch notwendig, um die Website auszuliefern und deren Sicherheit zu gewährleisten (Art. 6 Abs. 1 lit. f DSGVO). Eine
        Zusammenführung mit anderen Datenquellen findet nicht statt.
      </p>

      <h2>3. Cookies und lokale Speicherung</h2>
      <p>
        Diese Website verwendet keine Tracking- oder Marketing-Cookies. Es wird ausschließlich der technisch notwendige Eintrag in
        Ihrem Browser (Local Storage) gespeichert, dass Sie den Cookie-Hinweis bestätigt haben. Diese Information verlässt Ihr Gerät
        nicht und enthält keine personenbezogenen Daten.
      </p>

      <h2>4. Eingebettete Karte (Google Maps)</h2>
      <p>
        Zur Darstellung unseres Standorts binden wir Google Maps ein (Google Ireland Limited, Gordon House, Barrow Street,
        Dublin 4, Irland). Beim Laden der Karte werden unter anderem Ihre IP-Adresse und technische Browserdaten an Google
        übertragen. Google kann Cookies verwenden und Daten auch in den USA verarbeiten. Weitere Informationen finden Sie in der{" "}
        <a href="https://policies.google.com/privacy?hl=de" target="_blank" rel="noreferrer">Datenschutzerklärung von Google</a>.
      </p>

      <h2>5. Externe Links (Google Maps, Instagram)</h2>
      <p>
        Unsere Website enthält Links zu Google Maps (Google Ireland Ltd.) und Instagram (Meta Platforms Ireland Ltd.). Diese Dienste
        werden erst aktiv, wenn Sie die Links anklicken. Ab diesem Zeitpunkt gelten die Datenschutzbestimmungen des jeweiligen Anbieters.
      </p>

      <h2>6. Kontaktaufnahme</h2>
      <p>
        Bei telefonischer oder sonstiger Kontaktaufnahme verarbeiten wir Ihre Angaben zur Bearbeitung der Anfrage (Art. 6 Abs. 1 lit. b
        DSGVO). Die Daten werden gelöscht, sobald sie für den Zweck nicht mehr erforderlich sind und keine gesetzlichen
        Aufbewahrungspflichten bestehen.
      </p>

      <h2>7. Ihre Rechte</h2>
      <p>
        Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit und Widerspruch
        (Art. 15–21 DSGVO) sowie das Recht, sich bei einer Datenschutz-Aufsichtsbehörde zu beschweren. Zuständig ist u. a. die
        Landesbeauftragte für den Datenschutz Niedersachsen, Prinzenstraße 5, 30159 Hannover.
      </p>

        <p className="legal-note">
          Hinweis: Die mit [eckigen Klammern] markierten Angaben sind Platzhalter und müssen vor Veröffentlichung durch die tatsächlichen
          Betreiberdaten ersetzt werden.
        </p>
      </main>
    </>
  );
}
