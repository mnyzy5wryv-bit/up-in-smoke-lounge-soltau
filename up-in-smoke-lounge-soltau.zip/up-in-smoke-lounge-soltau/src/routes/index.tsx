import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, Instagram, MapPin, Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { BrandLogo } from "@/components/brand-logo";
import { DrinksMenu } from "@/components/drinks-menu";
import heroImage from "@/assets/hero.webp";
import smokeImage from "@/assets/smoke-overlay.webp";
import drinkImage from "@/assets/drink.webp";
import event1 from "@/assets/event-1.webp";
import event2 from "@/assets/event-2.webp";
import event3 from "@/assets/event-3.webp";
import poster1 from "@/assets/poster-1.jpeg";
import poster2 from "@/assets/poster-2.jpeg";
import poster3 from "@/assets/poster-3.jpeg";

const SITE_URL = "https://upinsmoke-soltau.de";
const OG_IMAGE = `${SITE_URL}/og-image.jpg`;

const PAGE_TITLE = "Shisha Bar & Lounge in Soltau | UP IN SMOKE LOUNGE";
const PAGE_DESCRIPTION =
  "UP IN SMOKE LOUNGE – Shisha Bar, Café und Lounge in Soltau, Wilhelmstraße 25. Gute Shisha, kalte Drinks, Events und lange Abende. Täglich ab 17 Uhr geöffnet.";

const openingHours = [
  { day: "Montag", time: "17:00 — 02:00", schema: ["Monday", "17:00", "02:00"] },
  { day: "Dienstag", time: "17:00 — 02:00", schema: ["Tuesday", "17:00", "02:00"] },
  { day: "Mittwoch", time: "17:00 — 02:00", schema: ["Wednesday", "17:00", "02:00"] },
  { day: "Donnerstag", time: "17:00 — 02:00", schema: ["Thursday", "17:00", "02:00"] },
  { day: "Freitag", time: "17:00 — 05:00", schema: ["Friday", "17:00", "05:00"] },
  { day: "Samstag", time: "17:00 — 05:00", schema: ["Saturday", "17:00", "05:00"] },
  { day: "Sonntag", time: "17:00 — 02:00", schema: ["Sunday", "17:00", "02:00"] },
];

export const Route = createFileRoute("/")({
  staticData: { sitemap: true },
  component: Index,
  head: () => ({
    meta: [
      { title: PAGE_TITLE },
      { name: "description", content: PAGE_DESCRIPTION },
      {
        name: "keywords",
        content:
          "Shisha Bar Soltau, Shisha Lounge Soltau, UP IN SMOKE LOUNGE Soltau, Shisha Soltau, Lounge Soltau, Bar Soltau",
      },
      { property: "og:title", content: PAGE_TITLE },
      { property: "og:description", content: PAGE_DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: `${SITE_URL}/` },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "UP IN SMOKE LOUNGE Logo" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: PAGE_TITLE },
      { name: "twitter:description", content: PAGE_DESCRIPTION },
      { name: "twitter:image", content: OG_IMAGE },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BarOrPub",
          "@id": `${SITE_URL}/#localbusiness`,
          name: "UP IN SMOKE LOUNGE",
          alternateName: "Up in Smoke Soltau",
          description: PAGE_DESCRIPTION,
          url: SITE_URL,
          logo: `${SITE_URL}/logo.png`,
          image: [`${SITE_URL}/logo.png`, OG_IMAGE],
          telephone: "+4915226392702",
          priceRange: "€€",
          currenciesAccepted: "EUR",
          paymentAccepted: "Bargeld, EC-Karte (ab 20 €)",
          servesCuisine: "Shisha, Getränke, Cocktails",
          smokingAllowed: true,
          parentOrganization: { "@id": `${SITE_URL}/#organization` },
          sameAs: ["https://www.instagram.com/upinsmoke.soltau/"],
          address: {
            "@type": "PostalAddress",
            streetAddress: "Wilhelmstraße 25",
            postalCode: "29614",
            addressLocality: "Soltau",
            addressRegion: "Niedersachsen",
            addressCountry: "DE",
          },
          geo: { "@type": "GeoCoordinates", latitude: 52.9863, longitude: 9.8433 },
          areaServed: { "@type": "City", name: "Soltau" },
          openingHoursSpecification: openingHours.map(({ schema }) => ({
            "@type": "OpeningHoursSpecification",
            dayOfWeek: `https://schema.org/${schema[0]}`,
            opens: schema[1],
            closes: schema[2],
          })),
        }),
      },
    ],
  }),
});


const events = [
  { image: event1, note: "Angebot des Abends", title: "Ladies Special" },
  { image: event2, note: "Sommerabend", title: "Tropical Ibiza" },
  { image: event3, note: "Samstag bei uns", title: "Saturday Memories" },
];

function Brand() {
  return <BrandLogo home />;
}

function Index() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cookieVisible, setCookieVisible] = useState(false);

  useEffect(() => {
    setCookieVisible(window.localStorage.getItem("up-cookie-ok") !== "yes");
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("up-cookie-ok", "yes");
    setCookieVisible(false);
  };

  return (
    <main className="overflow-hidden bg-background text-foreground">
      <header className="site-header">
        <Brand />
        <nav className={mobileOpen ? "nav-open" : ""} aria-label="Hauptnavigation">
          <a href="#experience" onClick={() => setMobileOpen(false)}>Lounge</a>
          <a href="#drinks" onClick={() => setMobileOpen(false)}>Karte</a>
          <a href="#events" onClick={() => setMobileOpen(false)}>Abende</a>
          <a href="#standort" onClick={() => setMobileOpen(false)}>Standort</a>
          <a className="nav-cta" href="tel:+4915226392702">Tisch anfragen</a>
        </nav>
        <Button variant="ghost" size="icon" className="nav-toggle" aria-label="Menü öffnen" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X /> : <Menu />}
        </Button>
      </header>

      <section id="top" className="hero">
        <img className="hero-photo" src={heroImage} alt="Gast mit Shisha in der UP IN SMOKE LOUNGE in Soltau" fetchPriority="high" decoding="async" />
        <div className="hero-shade" />
        <div className="hero-smoke" aria-hidden="true">
          <img src={smokeImage} width={1536} height={1024} alt="" decoding="async" className="smoke-layer smoke-layer-front" />
          <img src={smokeImage} width={1536} height={1024} alt="" decoding="async" className="smoke-layer smoke-layer-back" />
        </div>
        <div className="hero-watermark" aria-hidden="true"><span>UP</span><small>UP IN SMOKE</small></div>
        <div className="hero-copy">
          <p className="kicker">CAFÉ · BAR · LOUNGE · SOLTAU</p>
          <h1>ANKOMMEN.<br/><em>ABSCHALTEN.</em></h1>
          <p className="hero-text">Gute Shisha, starke Drinks und Musik im Hintergrund. Mehr muss ein guter Abend manchmal nicht können.</p>
          <div className="flex flex-wrap gap-3">
            <Button variant="gold" size="lounge" asChild><a href="#experience">Komm rein</a></Button>
            <Button variant="smoke" size="lounge" asChild><a href="#drinks">Karte ansehen</a></Button>
          </div>
        </div>
        <div className="hero-bottom">
          <a href="https://www.instagram.com/upinsmoke.soltau/" target="_blank" rel="noreferrer"><small>AUF INSTAGRAM</small>@upinsmoke.soltau</a>
          <span><small>BEI UNS</small>Shisha · Drinks · Musik</span>
        </div>
        <a className="scroll-cue" href="#experience">WEITER NACH UNTEN <ArrowDown /></a>
      </section>

      <div className="ticker" aria-hidden="true"><span>GUTE SHISHA&nbsp;&nbsp; KALTE DRINKS&nbsp;&nbsp; LANGE ABENDE&nbsp;&nbsp; SOLTAU&nbsp;&nbsp; GUTE SHISHA&nbsp;&nbsp; KALTE DRINKS</span></div>

      <section id="experience" className="experience section-shell">
        <div className="section-heading">
          <p>01 — DIE LOUNGE</p>
          <h2>SETZ DICH.<br/><em>BLEIB NOCH.</em></h2>
          <div className="section-copy"><p>Kein Dresscode. Kein großes Gerede. Einfach ein Tisch, gute Leute und Zeit, die nicht drängelt.</p><p>Wir kümmern uns um Kopf, Kohle und Glas. Du um den Rest.</p></div>
        </div>
        <div className="experience-art">
          <div className="mini-brand"><Brand /><span>LOUNGE · SOLTAU</span></div>
          <p className="big-quote">EINFACH MAL<br/><strong>RUNTER</strong> <em>kommen.</em></p>
          <img src={drinkImage} alt="Signature Drink der UP IN SMOKE LOUNGE Soltau in warmem Goldlicht" loading="lazy" />
          <p className="no-rush"><strong>∞</strong> KEIN ZEITDRUCK</p>
        </div>
      </section>

      <section id="drinks" className="drinks section-shell">
        <div className="section-heading horizontal"><div><p>02 — DIE KARTE</p><h2>WAS DARF'S<br/><em>HEUTE SEIN?</em></h2></div><p className="section-copy">Von Softdrinks bis Longdrinks. Ohne Show, ordentlich eingeschenkt.</p></div>
        <DrinksMenu />
      </section>

      <section id="events" className="events section-shell">
        <div className="section-heading"><p>03 — BEI UNS LÄUFT WAS</p><h2>NICHT JEDER ABEND<br/><em>IST GLEICH.</em></h2></div>
        <div className="event-grid">{events.map((event, index) => <article className="event-card" key={event.title}><img src={event.image} alt={`${event.title} – Event in der UP IN SMOKE LOUNGE Soltau`} loading="lazy"/><div className="event-copy"><span>0{index + 1}</span><small>{event.note}</small><h3>{event.title}</h3></div></article>)}</div>
      </section>

      <section className="posters section-shell">
        <div className="section-heading"><p>04 — AKTUELLES</p><h2>GUT ZU <em>WISSEN.</em></h2></div>
        <div className="poster-grid"><img src={poster1} alt="Cocktail Happy Hour in der UP IN SMOKE LOUNGE Soltau, täglich 19 bis 21 Uhr" loading="lazy"/><img src={poster2} alt="Smoke Slow, Stay Long – Shisha Lounge Soltau" loading="lazy"/><img src={poster3} alt="Kartenzahlung ab 20 Euro in der UP IN SMOKE LOUNGE Soltau möglich" loading="lazy"/></div>
      </section>

      <section id="standort" className="location section-shell">
        <div className="location-intro">
        <div className="section-heading"><p>05 — SO FINDEST DU UNS</p><h2>MITTEN IN<br/><em>SOLTAU.</em></h2><p className="section-copy">Schnell gefunden, schwer wieder verlassen. Karte öffnen, Route starten – und den Rest machen wir.</p></div>
        <div className="location-map">
          <iframe
            title="Google Maps – UP IN SMOKE LOUNGE in Soltau"
            src="https://www.google.com/maps?q=Up%20in%20Smoke%20Soltau%2C%20Wilhelmstra%C3%9Fe%2025%2C%2029614%20Soltau&output=embed&z=16"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
          <Button variant="smoke" size="lounge" asChild>
            <a href="https://www.google.com/maps/search/?api=1&query=Up%20in%20Smoke%20Soltau%2C%20Wilhelmstra%C3%9Fe%2025%2C%2029614%20Soltau" target="_blank" rel="noreferrer"><MapPin /> Route starten <ArrowRight /></a>
          </Button>
        </div>
        </div>
        <div className="location-details">
          <a className="address" href="https://www.google.com/maps/search/?api=1&query=Up%20in%20Smoke%20Soltau%2C%20Wilhelmstra%C3%9Fe%2025%2C%2029614%20Soltau" target="_blank" rel="noreferrer"><MapPin /> Wilhelmstraße 25<br/>29614 Soltau</a>
          <ul>{openingHours.map(({ day, time }) => <li key={day}><span>{day}</span><strong>{time}</strong></li>)}</ul>
          <div className="contact-links"><a href="tel:+4915226392702"><Phone /> 01522 6392702</a><a href="https://www.instagram.com/upinsmoke.soltau/" target="_blank" rel="noreferrer"><Instagram /> @upinsmoke.soltau</a></div>
        </div>
      </section>

      <footer><p>HEUTE NOCH NICHTS VOR?</p><h2>DEIN TISCH. <em>DEIN ABEND.</em></h2><Button variant="gold" size="lounge" asChild><a href="tel:+4915226392702">Jetzt anrufen</a></Button><Brand /><div className="legal-bar"><Link to="/impressum">Impressum</Link><span>·</span><Link to="/datenschutz">Datenschutz</Link></div></footer>

      {cookieVisible && <aside className="cookie"><div><strong>Datenschutz & Cookies</strong><p>Wir speichern, dass du diesen Hinweis gesehen hast. Die eingebettete Google-Karte kann Daten an Google übertragen und Cookies verwenden. Details findest du in der <Link to="/datenschutz">Datenschutzerklärung</Link>.</p></div><Button variant="gold" size="lounge" onClick={acceptCookies}>Alles klar</Button></aside>}


    </main>
  );
}
