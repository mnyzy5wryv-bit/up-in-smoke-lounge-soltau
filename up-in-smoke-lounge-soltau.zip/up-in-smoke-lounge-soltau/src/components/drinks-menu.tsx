import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { drinkSlug, menuCategories } from "@/data/menu";

const drinkImages = import.meta.glob("../assets/drinks/*.jpg", { eager: true, import: "default" }) as Record<string, string>;
const imageFor = (name: string, fallback: string) =>
  drinkImages[`../assets/drinks/${drinkSlug(name)}.jpg`] ?? fallback;

const ease = [0.22, 1, 0.36, 1] as const;

export function DrinksMenu() {
  const [categoryIndex, setCategoryIndex] = useState(0);
  const [itemIndex, setItemIndex] = useState(0);


  const category = menuCategories[categoryIndex] ?? menuCategories[0]!;
  const flatItems = useMemo(
    () => category.groups.flatMap((g) => g.items.map((item) => ({ group: g.label, item }))),
    [category],
  );
  useEffect(() => {
    flatItems.forEach(({ item }) => {
      const img = new Image();
      img.src = imageFor(item.name, category.image);
    });
  }, [flatItems, category.image]);
  const active = flatItems[itemIndex] ?? flatItems[0]!;

  return (
    <MotionConfig reducedMotion="user">
      <motion.div
        className="premium-menu premium-inline"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.7, ease }}
      >
        <div className="premium-layout">
          <div className="premium-stage">
            <AnimatePresence mode="wait">
              <motion.img
                key={`${category.id}-${itemIndex}`}
                src={imageFor(active.item.name, category.image)}
                alt={`${active.item.name} – ${category.title} in der UP IN SMOKE LOUNGE Soltau`}
                width={1024}
                height={1280}
                className="premium-image"
                initial={{ opacity: 0, scale: 1.12, x: 30, rotate: 1.5 }}
                animate={{ opacity: 1, scale: 1, x: 0, rotate: 0 }}
                exit={{ opacity: 0, scale: 0.95, x: -30, rotate: -1.5 }}
                transition={{ duration: 0.6, ease }}
              />
            </AnimatePresence>
            <div className="premium-caption">
              <AnimatePresence mode="wait">
                <motion.div
                  key={`${category.id}-${itemIndex}`}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  variants={{
                    hidden: {},
                    visible: { transition: { staggerChildren: 0.08 } },
                    exit: { opacity: 0, y: 12, transition: { duration: 0.2 } },
                  }}
                >
                  {[
                    <p key="g" className="premium-group">{active.group}</p>,
                    <h3 key="h">{active.item.name}</h3>,
                    active.item.note ? <p key="n" className="premium-note">{active.item.note}</p> : null,
                    <div key="p" className="premium-prices">
                      {active.item.prices.map((p) => (
                        <span key={`${p.size}-${p.price}`}>
                          {p.size && <small>{p.size}</small>}
                          <strong>{p.price} €</strong>
                        </span>
                      ))}
                    </div>,
                  ]
                    .filter(Boolean)
                    .map((el, i) => (
                      <motion.div
                        key={i}
                        variants={{
                          hidden: { opacity: 0, y: 16, filter: "blur(6px)" },
                          visible: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.45, ease } },
                        }}
                      >
                        {el}
                      </motion.div>
                    ))}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <div className="premium-list">
            <div className="premium-tabs" role="tablist" aria-label="Kategorien">
              {menuCategories.map((cat, index) => (
                <button
                  key={cat.id}
                  role="tab"
                  aria-selected={index === categoryIndex}
                  className={index === categoryIndex ? "active" : ""}
                  onClick={() => {
                    setCategoryIndex(index);
                    setItemIndex(0);
                  }}
                >
                  <small>0{index + 1}</small>
                  {cat.title}
                </button>
              ))}
            </div>
            <p className="premium-subtitle">{category.subtitle}</p>
            <div className="premium-items">
              <AnimatePresence mode="wait">
                <motion.ul
                  key={category.id}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, y: -12, transition: { duration: 0.2 } }}
                  variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.045 } } }}
                >
                  {flatItems.map(({ group, item }, index) => (
                    <motion.li
                      key={`${group}-${item.name}`}
                      variants={{
                        hidden: { opacity: 0, x: 40 },
                        visible: { opacity: 1, x: 0, transition: { duration: 0.45, ease } },
                      }}
                    >
                      <motion.button
                        className={index === itemIndex ? "active" : ""}
                        aria-pressed={index === itemIndex}
                        onClick={() => setItemIndex(index)}
                        onMouseEnter={() => setItemIndex(index)}
                        whileHover={{ x: 8 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <span>
                          <small>{group}</small>
                          {item.name}
                        </span>
                        <em>{item.prices.map((p) => `${p.price} €`).join(" · ")}</em>
                      </motion.button>
                    </motion.li>
                  ))}
                </motion.ul>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </motion.div>
    </MotionConfig>
  );
}
