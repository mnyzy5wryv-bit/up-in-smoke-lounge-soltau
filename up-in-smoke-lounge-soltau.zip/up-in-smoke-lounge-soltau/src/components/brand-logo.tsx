import { Link } from "@tanstack/react-router";

type BrandLogoProps = {
  className?: string;
  home?: boolean;
};

export function BrandLogo({ className = "", home = false }: BrandLogoProps) {
  const image = (
    <img
      src="/logo.png"
      alt="UP IN SMOKE LOUNGE Logo"
      width={1024}
      height={1024}
      decoding="async"
    />
  );

  if (home) {
    return (
      <a href="#top" className={`brand ${className}`.trim()} aria-label="UP IN SMOKE LOUNGE Startseite">
        {image}
      </a>
    );
  }

  return (
    <Link to="/" className={`brand ${className}`.trim()} aria-label="UP IN SMOKE LOUNGE Startseite">
      {image}
    </Link>
  );
}