import heroErfrischendes from "@/assets/menu-hero-erfrischendes.jpg";
import heroKaffee from "@/assets/menu-hero-kaffee.jpg";
import heroBiere from "@/assets/menu-hero-biere.jpg";
import heroPrickelndes from "@/assets/menu-hero-prickelndes.jpg";

export type MenuPrice = { size: string; price: string };

export type MenuItem = {
  name: string;
  note?: string;
  prices: MenuPrice[];
};

export type MenuGroup = {
  label: string;
  items: MenuItem[];
};

export type MenuCategory = {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  groups: MenuGroup[];
};

export const menuCategories: MenuCategory[] = [
  {
    id: "erfrischendes",
    title: "Erfrischendes",
    subtitle: "Softdrinks, Säfte, Spritzer & hausgemachte Limonaden",
    image: heroErfrischendes,
    groups: [
      {
        label: "Softdrinks",
        items: [
          {
            name: "Coca-Cola / Coca-Cola Zero",
            prices: [
              { size: "Fl. 0,2L", price: "3,50" },
              { size: "0,4L", price: "3,80" },
            ],
          },
          {
            name: "Fanta / Sprite / Spezi",
            prices: [
              { size: "Fl. 0,2L", price: "3,50" },
              { size: "0,4L", price: "3,80" },
            ],
          },
          {
            name: "S. Pellegrino / Acqua Panna (still)",
            prices: [
              { size: "0,25L", price: "3,00" },
              { size: "0,7L", price: "6,10" },
            ],
          },
          {
            name: "Red Bull Original / Sugar Free / Editions",
            prices: [{ size: "0,25L", price: "4,50" }],
          },
          {
            name: "Moloko Original / Sugar Free / Cranberry",
            prices: [{ size: "0,25L", price: "4,20" }],
          },
          {
            name: "Elephant Bay Ice Tea",
            note: "Melon · Peach · Lemon · Blueberry · Mango · Ananas · Kirsche · Granatapfel",
            prices: [{ size: "Fl. 0,33L", price: "3,80" }],
          },
          {
            name: "Elephant Bay Lemonade",
            note: "Exotic · Mandarine · Pink Grapefruit · Lime Mint",
            prices: [{ size: "Fl. 0,33L", price: "3,80" }],
          },
          {
            name: "Schweppes",
            note: "Bitter Lemon · Tonic · Ginger Ale · Russian Wild Berry",
            prices: [{ size: "Fl. 0,2L", price: "3,30" }],
          },
        ],
      },
      {
        label: "Säfte & Nektare",
        items: [
          {
            name: "Säfte & Nektare",
            note: "Apfel · Orange · Cranberry · Maracuja · Banane · Kirsche · Ananas — auch als Schorle",
            prices: [
              { size: "Fl. 0,3L", price: "3,50" },
              { size: "0,4L", price: "4,10" },
            ],
          },
        ],
      },
      {
        label: "Fancy Spritzer",
        items: [
          {
            name: "Fancy Spritzer",
            note: "Auf Maracujanektar & Soda: Erdbeere · Kokos · Himbeere · Blue Curaçao · Wassermelone · Waldmeister · Holunderblüte",
            prices: [{ size: "0,4L", price: "5,90" }],
          },
        ],
      },
      {
        label: "Aura Lemonades",
        items: [
          {
            name: "Aura Lemonades",
            note: "Frisch & hausgemacht: Erdbeer-Minze · Kokos-Limette · Wassermelone-Minze · Holunderblüte-Gurke · Maracuja-Minze · Pfirsich-Minze · Granatapfel-Minze",
            prices: [{ size: "0,4L", price: "5,90" }],
          },
        ],
      },
    ],
  },
  {
    id: "heiss-kalt",
    title: "Heiß- & Kaltgetränke",
    subtitle: "Coffee, Tea & mehr",
    image: heroKaffee,
    groups: [
      {
        label: "Coffee",
        items: [
          { name: "Cafe Crema", prices: [{ size: "", price: "2,90" }] },
          { name: "Cappuccino", prices: [{ size: "", price: "3,50" }] },
          { name: "Latte Macchiato", prices: [{ size: "", price: "3,10" }] },
          { name: "Chai-Tea Latte", prices: [{ size: "", price: "3,30" }] },
          {
            name: "Heiße Schokolade",
            note: "+ extra Sahne 3,60",
            prices: [{ size: "", price: "3,30" }],
          },
          { name: "Milchkaffee", prices: [{ size: "", price: "3,30" }] },
          { name: "Espresso", prices: [{ size: "", price: "2,50" }] },
          { name: "Espresso Doppio", prices: [{ size: "", price: "3,00" }] },
          { name: "Espresso Macchiato", prices: [{ size: "", price: "3,50" }] },
          { name: "Eiskaffee", prices: [{ size: "", price: "4,50" }] },
        ],
      },
      {
        label: "Tea",
        items: [
          { name: "Frische heiße Zitrone", prices: [{ size: "", price: "3,50" }] },
          { name: "Frischer Minztee", prices: [{ size: "", price: "3,50" }] },
          { name: "Frischer Ingwer-Minztee", prices: [{ size: "", price: "3,50" }] },
          { name: "Grüner Tee", prices: [{ size: "", price: "3,00" }] },
          { name: "Rooibostee", prices: [{ size: "", price: "2,70" }] },
          { name: "Früchtetee", prices: [{ size: "", price: "2,70" }] },
          {
            name: "Çay",
            prices: [
              { size: "Small", price: "1,50" },
              { size: "Big", price: "3,00" },
            ],
          },
          { name: "Aura Apfeltee", prices: [{ size: "", price: "3,50" }] },
          { name: "Wellnesstee mit Früchten", prices: [{ size: "", price: "4,50" }] },
        ],
      },
      {
        label: "Upgrades",
        items: [
          {
            name: "Flavour nach Wahl",
            note: "Karamell · Vanille · Schoko · Zimt · Haselnuss · Kokos",
            prices: [{ size: "", price: "+ 0,80" }],
          },
          {
            name: "Baileys / Brauner Rum / Amaretto",
            prices: [{ size: "", price: "+ 1,50" }],
          },
        ],
      },
    ],
  },
  {
    id: "biere-weine",
    title: "Biere & Weine",
    subtitle: "Vom Fass, Flasche & offene Weine",
    image: heroBiere,
    groups: [
      {
        label: "Beers",
        items: [
          {
            name: "San Miguel (vom Fass)",
            prices: [{ size: "0,33L", price: "4,10" }],
          },
          { name: "Becks", prices: [{ size: "Fl. 0,33L", price: "3,50" }] },
          {
            name: "Becks Blue (alkoholfrei)",
            prices: [{ size: "Fl. 0,33L", price: "3,50" }],
          },
          {
            name: "Becks Green Lemon",
            prices: [{ size: "Fl. 0,33L", price: "3,50" }],
          },
          { name: "Becks Gold", prices: [{ size: "Fl. 0,33L", price: "3,50" }] },
          {
            name: "Corona Extra",
            prices: [{ size: "Fl. 0,35L", price: "4,10" }],
          },
          {
            name: "Franziskaner Hefeweizen (vom Fass)",
            prices: [{ size: "Fl. 0,5L", price: "4,20" }],
          },
          {
            name: "Franziskaner (alkoholfrei)",
            prices: [{ size: "Fl. 0,5L", price: "4,20" }],
          },
          { name: "Heineken", prices: [{ size: "Fl. 0,2L", price: "4,10" }] },
        ],
      },
      {
        label: "White Wine",
        items: [
          {
            name: "Chardonnay",
            prices: [
              { size: "0,2L", price: "5,50" },
              { size: "Fl. 0,75L", price: "25,00" },
            ],
          },
          {
            name: "Riesling (trocken)",
            prices: [
              { size: "0,2L", price: "5,50" },
              { size: "Fl. 0,75L", price: "25,00" },
            ],
          },
          {
            name: "Sauvignon Blanc",
            prices: [{ size: "Fl. 0,75L", price: "25,00" }],
          },
          {
            name: "Fragolino",
            prices: [{ size: "Fl. 0,75L", price: "45,00" }],
          },
          { name: "Weinschorle", prices: [{ size: "0,2L", price: "5,00" }] },
          {
            name: "Weinschorle mit Ginger Ale",
            prices: [{ size: "0,2L", price: "5,00" }],
          },
          {
            name: "Weinschorle Aura mit Sprite",
            prices: [{ size: "0,2L", price: "5,00" }],
          },
        ],
      },
      {
        label: "Red Wine & Rosé",
        items: [
          {
            name: "Merlot",
            prices: [
              { size: "0,2L", price: "4,10" },
              { size: "Fl. 0,75L", price: "20,00" },
            ],
          },
          {
            name: "Chianti",
            prices: [
              { size: "0,2L", price: "4,30" },
              { size: "Fl. 0,75L", price: "22,00" },
            ],
          },
          { name: "Roséwein", prices: [{ size: "0,2L", price: "4,50" }] },
        ],
      },
    ],
  },
  {
    id: "prickelndes",
    title: "Prickelndes",
    subtitle: "Aperitives, Champagne & Prosecco",
    image: heroPrickelndes,
    groups: [
      {
        label: "Aperitives",
        items: [
          { name: "Aperol Spritz", prices: [{ size: "0,2L", price: "5,50" }] },
          { name: "Hugo", prices: [{ size: "0,2L", price: "5,50" }] },
          { name: "Lillet Wild Berry", prices: [{ size: "0,2L", price: "5,50" }] },
          { name: "Campari Spritz", prices: [{ size: "0,2L", price: "5,50" }] },
          {
            name: "Tocco Rosso",
            note: "Campari, Holunderblütensirup, Prosecco",
            prices: [{ size: "0,2L", price: "5,50" }],
          },
          {
            name: "Lillet Marie",
            note: "mit Cranberrysaft",
            prices: [{ size: "0,2L", price: "5,50" }],
          },
        ],
      },
      {
        label: "Drivers Aperitives (alkoholfrei)",
        items: [
          { name: "Hugo (alkoholfrei)", prices: [{ size: "0,2L", price: "4,50" }] },
          { name: "Mint & Fresh", prices: [{ size: "0,2L", price: "3,70" }] },
        ],
      },
      {
        label: "Champagne & Prosecco",
        items: [
          { name: "Scavi & Ray", prices: [{ size: "0,1L", price: "3,50" }] },
          { name: "Scavi & Ray Rosé", prices: [{ size: "0,1L", price: "3,50" }] },
        ],
      },
    ],
  },
];

export function drinkSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss").replace(/ç/g, "c")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}
